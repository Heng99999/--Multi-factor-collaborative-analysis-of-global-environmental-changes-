from PIL import Image


def convert_to_binary(image_path, threshold):
    # 打开图像文件
    img = Image.open("D:\\my_image.jpg").convert('L')  # 转为灰度图像
    pixels = img.load()

    # 创建一个新的二值化图像
    binary_img = Image.new('1', img.size)
    binary_pixels = binary_img.load()

    # 遍历图像像素，根据阈值进行二值化
    for i in range(img.size[0]):
        for j in range(img.size[1]):
            if pixels[i, j] > threshold:
                binary_pixels[i, j] = 1
            else:
                binary_pixels[i, j] = 0

    return binary_img


def count_snow_and_background(image_path, threshold):
    binary_img = convert_to_binary(image_path, threshold)
    binary_pixels = binary_img.load()

    snow_count = 0
    background_count = 0

    # 统计雪地和背景像素数量
    for i in range(binary_img.size[0]):
        for j in range(binary_img.size[1]):
            if binary_pixels[i, j] == 1:
                snow_count += 1
            else:
                background_count += 1

    return snow_count, background_count


# 测试代码
if __name__ == "__main__":
    image_path = "test_image.jpg"
    threshold = 128
    snow, background = count_snow_and_background(image_path, threshold)
    print(f"雪地像素数量: {snow}")
    print(f"背景像素数量: {background}")